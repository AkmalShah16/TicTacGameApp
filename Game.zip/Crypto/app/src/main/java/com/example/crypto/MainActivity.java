package com.example.crypto;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private boolean isPlayerX = true;
    private Button[][] buttons = new Button[3][3];
    private int[][] board = new int[3][3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GridLayout gridLayout = findViewById(R.id.gridLayout);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String buttonID = "button" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                board[i][j] = 0;
            }
        }
    }

    public void onGridButtonClick(View view) {
        Button button = (Button) view;
        int row = -1, col = -1;

        if (button.getId() == R.id.button00) {
            row = 0;
            col = 0;
        } else if (button.getId() == R.id.button01) {
            row = 0;
            col = 1;
        } else if (button.getId() == R.id.button02) {
            row = 0;
            col = 2;
        } else if (button.getId() == R.id.button10) {
            row = 1;
            col = 0;
        } else if (button.getId() == R.id.button11) {
            row = 1;
            col = 1;
        } else if (button.getId() == R.id.button12) {
            row = 1;
            col = 2;
        } else if (button.getId() == R.id.button20) {
            row = 2;
            col = 0;
        } else if (button.getId() == R.id.button21) {
            row = 2;
            col = 1;
        } else if (button.getId() == R.id.button22) {
            row = 2;
            col = 2;
        }

        if (board[row][col] == 0) {
            board[row][col] = isPlayerX ? 1 : 2;
            button.setText(isPlayerX ? "X" : "O");
            if (checkWin()) {
                Toast.makeText(this, (isPlayerX ? "X" : "O") + " wins!", Toast.LENGTH_LONG).show();
                disableButtons();
            } else {
                isPlayerX = !isPlayerX;
            }
        }
    }

    private boolean checkWin() {
        for (int i = 0; i < 3; i++) {
            if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != 0)
                return true;
            if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != 0)
                return true;
        }
        if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != 0)
            return true;
        if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != 0)
            return true;

        return false;
    }

    private void disableButtons() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setEnabled(false);
            }
        }
    }

    public void onResetButtonClick(View view) {
        isPlayerX = true;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = 0;
                buttons[i][j].setText("");
                buttons[i][j].setEnabled(true);
            }
        }
    }
}

